import{a as t}from"../chunks/entry.Ck56Y-cC.js";export{t as start};
